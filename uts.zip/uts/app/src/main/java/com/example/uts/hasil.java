package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import android.os.Bundle;

import android.widget.TextView;


public class hasil extends AppCompatActivity {
    Calendar myCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);
        myCalendar = Calendar.getInstance();

//      hasil inputan dari halaman data
        TextView Getinput1 = (TextView) findViewById(R.id.Getmatakuliah);
        Getinput1.setText("Matakuliah : " + getIntent().getStringExtra("matakuliah"));
        TextView Getinput2 = (TextView) findViewById(R.id.Getsks);
        Getinput2.setText("SKS : " + getIntent().getStringExtra("sks"));
        TextView Getinput4 = (TextView) findViewById(R.id.program);
        Getinput4.setText("PROGRAM STUDI " + getIntent().getStringExtra("studi"));
        TextView Getinput5 = (TextView) findViewById(R.id.Getdosen);
        Getinput5.setText("Dosen Pengampu : " + getIntent().getStringExtra("dosen"));
        TextView tanggal = (TextView) findViewById(R.id.Getanggal);
        tanggal.setText(getIntent().getStringExtra("tanggal"));
        TextView kelas = (TextView) findViewById(R.id.Getkelas);
        kelas.setText(getIntent().getStringExtra("Rbkelas"));
        TextView Getinput6 = (TextView) findViewById(R.id.Getnim);
        Getinput6.setText(getIntent().getStringExtra("getNim"));
        TextView Getinput7 = (TextView) findViewById(R.id.getname);
        Getinput7.setText(getIntent().getStringExtra("getData"));
    }
}