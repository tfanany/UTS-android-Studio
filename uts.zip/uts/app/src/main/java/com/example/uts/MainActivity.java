package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    String tmpK,Kelas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioButton kelasA = (RadioButton) findViewById(R.id.kelasa);
        kelasA.setOnClickListener(null);
        RadioButton kelasB = (RadioButton) findViewById(R.id.kelasb);
        kelasB.setOnClickListener(null);

        final EditText nim = (EditText) findViewById(R.id.nim);
        final EditText nama =(EditText) findViewById(R.id.nama);

//        untuk mengirim data ke halaman selanjutnya dengan button
        Button login = (Button) findViewById(R.id.btnLogin);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendData1 = new Intent(MainActivity.this,data.class);
                sendData1.putExtra("nim",nim.getText().toString());
                sendData1.putExtra("nama",nama.getText().toString());
                sendData1.putExtra("kelas",Kelas=tmpK.toString());
                startActivity(sendData1);
            }
        });
//      RadioButton

        RadioGroup group = (RadioGroup) findViewById (R.id.opsi);
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (kelasA.isChecked()){
                    tmpK="Kelas A";
                }else {
                    tmpK="Kelas B";
                }

            }
        });


            }

    }
