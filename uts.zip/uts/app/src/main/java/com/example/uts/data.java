package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import android.os.Bundle;

import static android.app.DatePickerDialog.*;

public class data extends AppCompatActivity {
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    String counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // memanggil data yang sudah diisi sebelumnya
        final TextView GetData1 = (TextView) findViewById(R.id.getNim);
        GetData1.setText("NIM Mahasiswa: "+getIntent().getStringExtra("nim"));

        final TextView GetData2 = (TextView) findViewById(R.id.getData);
        GetData2.setText("Nama Mahasiswa : "+getIntent().getStringExtra("nama"));

        final TextView GetData3 = (TextView) findViewById(R.id.getkelas);
        GetData3.setText("Kelas : "+getIntent().getStringExtra("kelas"));

//untuk menampilkan tanggal
        final TextView GetData4 = (TextView) findViewById(R.id.tanggal);
        String myFormat = "dd-MMMM-yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);



        // input data
        final EditText matakuliah = (EditText) findViewById(R.id.matakuliah);
        final EditText sks = (EditText) findViewById(R.id.sks);
        final EditText sifat= (EditText) findViewById(R.id.sifat);
        final EditText studimhs = (EditText) findViewById(R.id.studi);
        final EditText dosennmhs = (EditText) findViewById(R.id.dosen);
        Button reset = (Button) findViewById(R.id.btnreset);


        //datepicker
        final TextView datedeparture = (TextView) findViewById(R.id.datedeparture);
        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                GetData4.setText("Tanggal Pelaksanaan : " + sdf.format(myCalendar.getTime()));




            }

        };

//        datepicker
        datedeparture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(data.this, date,
                        myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();


            }
        });

//        mengirim data ke halaman selanjutnya
        Button submit = (Button) findViewById(R.id.btnsubmit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendData = new Intent(data.this,hasil.class);
                sendData.putExtra("matakuliah",matakuliah.getText().toString());
                sendData.putExtra("sks",sks.getText().toString());
                sendData.putExtra("sifat",sifat.getText().toString());
                sendData.putExtra("studi",studimhs.getText().toString());
                sendData.putExtra("dosen",dosennmhs.getText().toString());
                sendData.putExtra("getNim", GetData1.getText().toString());
                sendData.putExtra("getData", GetData2.getText().toString());
                sendData.putExtra("Rbkelas", GetData3.getText().toString());
                sendData.putExtra("tanggal", GetData4.getText().toString());
                startActivity(sendData);


            }
        });

//        untuk reset data yang sudah terisi
        reset.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                counter = "";
                matakuliah.setText("" + counter);
                sks.setText("" + counter);
                GetData4.setText("" + counter);
                sifat.setText("" + counter);
                studimhs.setText("" + counter);
                dosennmhs.setText("" + counter);
            }
        });
    }

}